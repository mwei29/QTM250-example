This repo is the source and data to generate this post: http://mookoom.blogspot.com/2013/01/modeling-psychophysical-data-with-non.html

The code is released under the [CC by attribution license](http://creativecommons.org/licenses/by-sa/3.0/). If you use it, please don't forget to mention where you got it.


